// js/api.js

const API = {
    // TEAM A INTEGRATION (OS Engine - Scheduling & Allocation)
    getSchedulingStatus: async (requestId) => {
        console.log(`[Team A] Fetching scheduling status for ${requestId}`);
        return { status: 'Scheduling' };
    },
    
    getAllocationStatus: async (requestId) => {
        console.log(`[Team A] Fetching allocation status for ${requestId}`);
        return { 
            status: 'Approved',
            allocatedLab: 'Lab 204'
        };
    },

    // TEAM B INTEGRATION (DSA Engine - Recommendation)
    getResourceRecommendation: async (date, time, capacity) => {
        console.log('[Team B] Generating resource recommendation...');
        // Simulating network delay
        return new Promise(resolve => setTimeout(() => resolve({
            suggestedLab: 'LAB 204',
            reason: 'Best available resource for requested time and capacity.'
        }), 500));
    },

    // TEAM C INTEGRATION (DBMS Engine - Database)
    createBookingRequest: async (bookingData) => {
        console.log('[Team C] Saving new booking request...', bookingData);
        // Mock successful save with delay
        return new Promise(resolve => setTimeout(() => {
            const requestId = 'REQ-' + Math.floor(1000 + Math.random() * 9000);
            resolve({ success: true, requestId: requestId });
        }, 800));
    },

    getMyBookings: async () => {
        console.log('[Team C] Fetching student bookings...');
        return {
            pending: [
                { id: 'REQ-001', lab: 'LAB 204', date: '2026-08-17', time: '10:00 - 12:00', submitted: '2026-08-16', status: 'Pending' },
                { id: 'REQ-002', lab: 'LAB 101', date: '2026-08-18', time: '14:00 - 16:00', submitted: '2026-08-16', status: 'Scheduling' }
            ],
            approved: [
                { id: 'BK-001', lab: 'LAB 204', date: '2026-08-17', time: '10:00 - 12:00', status: 'Confirmed' }
            ]
        };
    },

    getBookingStatus: async (requestId) => {
        console.log(`[Team C] Fetching status details for ${requestId}`);
        return {
            id: requestId,
            lab: 'LAB 204',
            date: '17 August 2026',
            time: '10:00 AM – 12:00 PM',
            purpose: 'Programming Practice',
            currentStatus: 'Scheduling' // Possible: Pending, Scheduling, Allocated, Approved, Rejected, Cancelled, Completed
        };
    },

    getAvailableLabs: async () => {
        console.log('[Team C] Fetching available labs...');
        return [
            { id: 'LAB101', name: 'LAB 101', total: 40, available: 15, occupied: 25, util: 62, status: 'AVAILABLE' },
            { id: 'LAB102', name: 'LAB 102', total: 40, available: 5, occupied: 35, util: 87, status: 'BUSY' },
            { id: 'LAB202', name: 'LAB 202', total: 30, available: 30, occupied: 0, util: 0, status: 'AVAILABLE' },
            { id: 'LAB204', name: 'LAB 204', total: 40, available: 18, occupied: 22, util: 55, status: 'AVAILABLE' },
            { id: 'LAB301', name: 'LAB 301', total: 35, available: 0, occupied: 0, util: 0, status: 'MAINTENANCE' }
        ];
    },

    // FACULTY SPECIFIC INTEGRATION
    submitFacultyBookingRequest: async (bookingData) => {
        console.log('[Team C] Saving new FACULTY booking request...', bookingData);
        return new Promise(resolve => setTimeout(() => {
            const requestId = 'REQ-F' + Math.floor(1000 + Math.random() * 9000);
            resolve({ success: true, requestId: requestId });
        }, 800));
    },

    getFacultyRequests: async () => {
        console.log('[Team C] Fetching faculty bookings...');
        return {
            pending: [
                { id: 'REQ-F1024', lab: 'LAB 204', date: '2026-08-17', time: '10:00 - 12:00', status: 'Pending' }
            ],
            approved: [
                { id: 'BK-F001', lab: 'LAB 201', date: '2026-08-19', time: '14:00 - 16:00', status: 'Faculty Reserved' }
            ]
        };
    }
};
