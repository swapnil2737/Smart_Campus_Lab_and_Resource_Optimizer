/**
 * Admin portal logic
 */

document.addEventListener('DOMContentLoaded', () => {
    console.log('Admin dashboard loaded.');
});
